# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 13:06:18 2020

@author: emredalyan
"""
value = int(input("0...10 arası bir sayi girin"))
if value >= 0:
    if value <= 10:
        print("evet 0 ile 10 arasında")
    else:
        print(value,"10dan büyük")
else:
        print(value,"0dan küçük")
        print("Bitti")
        


