# -*- coding: utf-8 -*-
"""
Created on Tue Nov  3 13:42:15 2020

@author: emredalyan
"""
toplam=0
kontrol=False
while not kontrol:
    deger=int(input("pozitif tam sayı giriniz"))
    if deger<0:
        print("negatif değer olan",deger,"engellendi")
        continue

    if deger!=999:
        print("tallying",deger)
        toplam+=deger
    else:
        kontrol= (deger==9990)

print("sum=",toplam)

