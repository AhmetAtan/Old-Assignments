# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 13:48:59 2020

@author: emredalyan
"""
from time import sleep 
for sayi in range(10,-1,-1):
    print(sayi)
    sleep(1)
    
