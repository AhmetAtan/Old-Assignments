# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 13:35:01 2020

@author: user
"""

from time import perf_counter
print('İsminizi giriniz',end="")
baslangic_zamani = perf_counter()
isim = input()
gecen_zaman = perf_counter() - baslangic_zamani
print(isim, "yazana kadar geçen zaman", gecen_zaman)
