# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:17:30 2020

@author: klyoner 
"""
x = int(input('Lütfen x değerini giriniz.'))

y = int(input('Lütfen y değerini giriniz.'))

sonuc = (x ** 3) + (y/4) + (3*y)

#Aşşağıdaki de doğru.

print((x ** 3) + (y/4) + (3*y))

print(sonuc)


