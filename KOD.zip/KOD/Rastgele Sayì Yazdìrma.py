# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 13:55:43 2020

@author: emredalyan
"""

from random import randrange, seed 
seed(23)
for i in  range (0,100):
    print(randrange(1,10001),end=';')
    
print()


