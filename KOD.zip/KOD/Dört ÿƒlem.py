# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 12:30:12 2020

@author: user
"""

a = 5

b = 3

carpim = a * b

cikartma =  a - b

toplama = a + b

bolme = a / b

kalan =  a % b

taban = a // b

kuvvet = a ** b

print ('carpmanin sonucu = ',carpim)

print ('cikartmanin sonucu = ',cikartma)

print ('toplamanin sonucu = ',toplama)

print ('bolmenin sonucu = ',bolme)

print ('kalanın sonucu =  ',kalan)

print ('tabanın sonucu =  ',taban)

print ('kuvvet sonucu =  ',kuvvet)
