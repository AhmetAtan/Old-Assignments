# -*- coding: utf-8 -*-
"""
Created on Tue Nov  3 13:23:15 2020

@author: emredalyan 
"""
cumle = input('Bir kelime yazınız:')
unlu_sayisi = 0
for c in cumle:
    if c =="A" or c == 'a' or c =="E" or c == 'e' 
      or c =="I" or c == 'i' or c =="O" or c == 'o'
      print(c,',',sep='',end='')
      unlu_sayisi += 1
print()

