2# -- coding: utf-8 --
"""
Created on Tue Oct 20 14:06:32 2020

@author: EmreDalyan
"""


anapara = int(input('Anaparayı giriniz:'))
yuzlira = anapara // 100
anapara = anapara % 100
ellilira = anapara // 50 
anapara = anapara % 50 
yirmilira = anapara // 20 
anapara = anapara % 20 
onlira = anapara // 10
anapara = anapara % 10
beslira = anapara // 5
anapara = anapara % 5
print ("yuzlira adeti:",yuzlira,"ellilira adeti:",ellilira,"yirmilira adeti:",yirmilira,"onlira adeti:",onlira,"beslira adeti",beslira)
