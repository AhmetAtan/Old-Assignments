# -*- coding: utf-8 -*-
"""
Created on Tue Nov  3 13:15:04 2020

@author: emredalyan
"""
word = input('Enter a word:')
for letter in word:
    print(letter)


for c in 'ABCDEF':
    print([',c,'], end='', sep='')
    print()
    
    

