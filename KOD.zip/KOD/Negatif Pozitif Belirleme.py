# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 11:58:56 2020

@author: emredalyan
"""

sayi = int(input('herhangi bir sayı giriniz'))

if(sayi < 0):
    print('negatif')
else:
    print('pozitif')
    
    