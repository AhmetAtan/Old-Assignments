# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 12:53:02 2020

@author: emredalyan
"""

from math import cos, sin, pi, radians
x = int(input('Bir değer giriniz'))
for n in (1,10):
    n=1
    L = 15

x=radians(x)

fonk_x = cos((n*pi*x)/L) + sin((n*pi*x)/L)

print(fonk_x)



