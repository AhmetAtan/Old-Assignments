# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 11:59:29 2020

@author: emredalyan
"""
c=1
deger=5
bosluk=2*deger - 2
for i in range(0,deger):
    for a in range(0,bosluk):
        print(end=" ")
    bosluk+=1
    for a in range(6,i,-1):
        print("* ",end="")
    print("")
bosluk=bosluk-1
for i in range(0,deger):
    for a in range(0,bosluk):
        print(end=" ")
    bosluk-=1
    c+=1
    for a in range(0,c):
        print("* ",end="")
    print("")
    
    

