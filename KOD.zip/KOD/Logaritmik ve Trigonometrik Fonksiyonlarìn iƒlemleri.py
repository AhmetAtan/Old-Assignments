# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 13:24:50 2020

@author: emredalyan
"""
from math import  log, cos, pi
 

y = 1
sum = 0
for y in range(1,15):
    sum+= y
    print(sum)
 
n = 10            
x=int(input("Bir x değeri giriniz"))
 
f_x=sum*(n*log(2,n)+ cos(2*pi))
 
 
print(f_x)

