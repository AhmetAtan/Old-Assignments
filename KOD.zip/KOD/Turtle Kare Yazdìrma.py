# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 14:02:46 2020

@author: emredalyan
"""
import turtle 
turtle.pencolor('blue')
turtle.forward(200)
turtle.left(90)

turtle.pencolor('red')
turtle.forward(200)
turtle.left(90)


turtle.pencolor('cyan')
turtle.forward(200)
turtle.left(90)


turtle.pencolor('black')
turtle.forward(200)
turtle.left(90)


turtle.pencolor('green')
turtle.forward(200)
turtle.left(90)




turtle.hideturtle()
turtle.exitonclick()

