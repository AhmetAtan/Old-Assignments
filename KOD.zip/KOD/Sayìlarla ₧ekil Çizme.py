# -*- coding: utf-8 -*-
"""
Created on Tue Nov  3 12:45:41 2020

@author: emredalyan 
"""
for i in range(16):
    print('{0:5} {1:5}'.format(i,10**i))

