# -*- coding: utf-8 -*-
"""
Created on Tue Nov  3 13:33:59 2020

@author: emredalyan
"""
boyut = int(input("Tablonun boyutunu giriniz:"))
for satir in range(1, boyut+1):
    for sutun in range(1, boyut+1):
        sonuc = satir*sutun 
    print('{0:4}' .format(sonuc), end='')
    