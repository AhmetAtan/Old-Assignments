# -*- coding: utf-8 -*-
"""
Created on Tue Nov  3 12:22:47 2020

@author: klyoner
"""
girdi = 0
toplam = 0
print("Lütfen pozitif bir sayı giriniz,negatif sayılar giriemez:")
while girdi >=0:
      girdi = int(input())
      if girdi >=0:
          toplam += girdi 
print("Sum",toplam) 


