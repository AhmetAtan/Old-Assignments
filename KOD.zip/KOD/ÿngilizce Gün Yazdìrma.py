# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 13:32:27 2020

@author: emredalyan
"""
data0=input("Lutfen sectiginiz gunu ingilizce giriniz:")

if data0=="monday" or "Monday":

 print("Pazartesi")

elif data0=="tuesday" or "Tuesday":

 print("Salı")

elif data0=="wednesday" or "Wednesday":

 print("Çarşamba")

elif data0=="thursday" or "Thursday":

 print("Perşembe")

elif data0=="friday" or "Friday":

 print("Cuma")

elif data0=="saturday" or "Saturday":

 print("Cumartesi")

elif data=="sunday" or "Sunday":

 print("Pazar")

else:

 print("Geçersiz Gün")
 
    
    
    
    