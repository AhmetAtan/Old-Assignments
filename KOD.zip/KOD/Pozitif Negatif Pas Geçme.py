# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 12:26:56 2020

@author: emredalyan
"""

x = 10 

if (x<0):
    pass
else:
    print('else e geldim')