# -*- coding: utf-8 -*-
"""
Created on Tue Nov  3 12:43:15 2020

@author: klyoner
"""

x = 0.0
while x != 1.0:
    print(x)
    x += 0.1
    print("Done")
    