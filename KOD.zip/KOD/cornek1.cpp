#include <stdio.h>

int main(int argc, char** argv) {
static void Main(string[] args)
        {
            double alis, karOran, satis;
            Console.Write("Say�y� Girin : ");
            alis = Convert.ToDouble(Console.ReadLine());
            Console.Write("Kar Oran�n� Girin : ");
            karOran = Convert.ToDouble(Console.ReadLine());
            satis = alis+(alis * karOran / 100);
            Console.WriteLine("Sat�� Fiyat� : {0}",satis);
            Console.ReadKey();
        }
	return 0;
}
