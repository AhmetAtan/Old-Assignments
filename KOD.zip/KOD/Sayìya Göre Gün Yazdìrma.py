# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 13:32:27 2020

@author: emredalyan
"""
x = int(input('Haftanın gününü giriniz:'))

if x == 1 :
  print("pazartesi")
elif x == 2 :
  print("salı")
elif x == 3 :
  print("carsamba")
elif x == 4 :
    print("persembe")
elif x == 5 :
    print("cuma")
elif x == 7 :
    print("cumartesi")
    
    