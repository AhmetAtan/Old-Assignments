# -*- coding: utf-8 -*-
"""
Created on Tue Nov 17 12:05:03 2020

@author: emredalyan
"""
def cift_tek(sayi):
    if sayi%2 == 0:
        return 'cift'
    else:
        return 'tek'
def main():
    sayi = int(input("Bir sayi giriniz"))
    sonuc = cift_tek(sayi)
    print(sonuc)
    
main()
