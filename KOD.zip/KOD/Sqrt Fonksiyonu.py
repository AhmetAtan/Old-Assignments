# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 12:06:33 2020

@author: emredalyan
"""
from math import sqrt 
x = 16
print(sqrt(x))
print(sqrt(2*x-5))
y = sqrt(3*x + 11)
print(y)


