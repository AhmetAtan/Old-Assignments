# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 13:26:30 2020

@author: emredalyan
"""

x = int(input('bir ile yüz arasında değer girin'))
 
if 1<=x<=100:
 print('Ok.')
else:
 print("Sınırın dışında.")
 