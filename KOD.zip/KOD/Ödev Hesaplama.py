# -*- coding: utf-8 -*-
"""
Created on Mon Nov  2 12:54:28 2020

@author: emredalyan
"""
puan= int(input("Aldığınız notu girin:"))
if(puan>100):
    print ("Geçersiz not girildi.")
elif(puan>=95):
    print ("A aldınız.")
elif(puan>=90):
    print ("A- aldınız.")
elif(puan>=85):
    print ("B+ aldınız.")
elif(puan>=80):
    print ("B aldınız.")
elif(puan>=75):
    print ("B- aldınız.")
elif(puan>=70):
    print ("C+ aldınız.")
elif(puan>=65):
    print ("C aldınız.")
elif(puan<=64):
    print ("F aldınız.")
    
    
    

        
