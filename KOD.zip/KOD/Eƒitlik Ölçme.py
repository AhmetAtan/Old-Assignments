# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 12:42:14 2020

@author: emredalyan
"""
d1 = 1.11 - 1.10
d2 = 2.11 - 2.10
print('d1=',d1,'d2=',d2)
if d1 == d2:
    print('Same')
else:
    print('Different')
    
        
