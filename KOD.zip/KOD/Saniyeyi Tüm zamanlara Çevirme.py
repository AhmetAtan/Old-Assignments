# -*- coding: utf-8 -*-
"""
Created on Tue Oct 20 13:47:23 2020

@author: klyoner
"""
#Verilen saniye cinsinden değeri saat, dakika ve saniye cinsinden çevirmek.

saniye = int(input('Saniyeyi giriniz.'))

saat = saniye // 3600

saniye = saniye % 3600

dakika = saniye // 60

saniye = saniye % 60 

print (saat,"saat",dakika,"dakika",saniye,"saniye")

