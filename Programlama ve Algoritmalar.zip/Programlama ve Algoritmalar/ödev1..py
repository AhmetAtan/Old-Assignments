# -- coding: utf-8 --
"""
Created on Tue Oct 20 14:06:32 2020

@author: klyoner
"""


anapara = int(input('anapara giriniz:'))
yuzlira = anapara // 100
anapara = anapara % 100
ellilira = anapara // 50 
anapara = anapara % 50 
yirmilira = anapara // 20 
anapara = anapara % 20 
onlira = anapara // 10
anapara = anapara % 10
beslira = anapara // 5
anapara = anapara % 5
print ("yuzlira",yuzlira,"ellilira",ellilira,"yirmilira",yirmilira,"onlira",onlira,"beslira",beslira)

#𝐦𝐞𝐝𝐢𝐩𝐨𝐥-ç𝐞𝐭 kanalına mesaj gönder