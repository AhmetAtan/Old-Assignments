# -*- coding: utf-8 -*-
"""
Created on Tue Nov 17 12:39:03 2020

@author: Sun Bilgisayar
"""

def gcd(n1, n2):
    min = n1 if n1 < n2 else n2
    largest_factor=1
    for i in range(1, min+1):
        if n1 % i == 0 and n2 % i == 0: largest_factor = i
    return largest_factor
num1=int(input("please enter an integer:"))
num2=int(input("please enter another integer:"))
min=num1 if num1<num2 else num2
print(gcd(num1,num2))