# -*- coding: utf-8 -*-
"""
Created on Tue Dec  1 12:25:20 2020

@author: Sun Bilgisayar
"""

def countdown(n):
    if n==0:
        print("sayım bitti")
    else:
        print(n) 
        countdown(n-1)
countdown(5)