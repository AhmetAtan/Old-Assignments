# -*- coding: utf-8 -*-
"""
Created on Tue Nov  3 12:53:58 2020

@author: Sun Bilgisayar
"""

for i in range (16):
    print("{0:5}){1:8}".format(i,10**i))