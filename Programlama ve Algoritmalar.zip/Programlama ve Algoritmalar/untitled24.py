# -*- coding: utf-8 -*-
"""
Created on Tue Dec 22 12:34:38 2020

@author: Sun Bilgisayar
"""

a[1][2]=5
print(a)