# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 12:18:36 2020

@author: Sun Bilgisayar
"""

from math import sqrt
x = 16
print (sqrt(x))
print(sqrt(16.0))
print(sqrt(2*x-5))
y = sqrt(3*x + 11)
print(y)

y = 2* sqrt(x+16)-4
print(y)
#print = (sqrt("45")) str hatası verir
