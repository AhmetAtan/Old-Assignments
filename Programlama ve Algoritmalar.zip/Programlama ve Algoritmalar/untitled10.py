# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 12:51:58 2020

@author: Sun Bilgisayar
"""

from math import pi,radians,cos,sin
L=15
toplam=0
sıralama=0
x=int(input("X için deger gidiriniz: "))
x=radians(x)
for n in range(1,11):
    islem= cos((n*pi*x)/L) + sin((n*pi*x)/L)
    toplam+=islem
    
    sıralama+=1
    print(sıralama,". işleminizin cevabı:",islem)
print("Hepsinin toplamı",toplam)