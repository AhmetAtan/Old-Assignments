# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 13:32:40 2020

@author: Sun Bilgisayar
"""

gün=int(input('Haftanin Gününü ingilizce yazınız:'))

if gün=="monday": 
    print('Pazartesi')
elif gün=="tuesday":
    print('Sali')
elif gün=="wednesday":
    print('Carsamba')
elif gün=="thursday":
    print('Persembe')
elif gün=="friday":
    print('Cuma')
elif gün=="saturday":
    print('Cumartesi')
elif gün=="sunday":
    print('Pazar')