# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 13:21:46 2020

@author: Sun Bilgisayar
"""

sayi=int(input("0-100 arası bir sayı giriniz:"))
if 1<=sayi<=100:
    print("ok")
else:
    print("Aralığı yanlış girdiniz")
    