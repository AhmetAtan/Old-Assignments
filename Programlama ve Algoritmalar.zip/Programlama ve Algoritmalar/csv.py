# -*- coding: utf-8 -*-
"""
Created on Tue Dec 15 13:08:33 2020

@author: Sun Bilgisayar
"""

import csv 
with open("file.csv", "r") as f:
    reader = csv.reader(f)
    your_list = list(reader)
print(your_list)
    