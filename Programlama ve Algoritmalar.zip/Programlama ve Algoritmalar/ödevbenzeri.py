# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 14:17:37 2020

@author: Sun Bilgisayar
"""

import turtle
y = -200 #ilk y değeri
#varsayılan hız ve varsayılan gecikme
turtle.color("red")
turtle.speed("slowest")
turtle.delay(2)
turtle.update()

for x in range(10):
    turtle.penup()
    turtle.setposition(-200, y)
    turtle.pendown()
    turtle.forward(400)
    y +=20
turtle.done()

turtle.hideturtle()
turtle.exitonclick()