# -*- coding: utf-8 -*-
"""
Created on Mon Jan 11 17:38:10 2021

@author: Sun Bilgisayar
"""

degerler={}
i=0
while (i<=3):
    
    ad=input("Adınızı Giriniz:")
    mail=input("Mail Adresinizi Giriniz:")
    numara=input("Telefon Numaranızı Giriniz:")
    
    degerler[ad]={
        "mail":mail,
        "numara":numara
        }
    ad=input("Aramak istediğiniz kişinin adını giriniz:")
    x=degerler[ad]
    print(x)
degerler=open("Dosyam.txt","w")
degerler.close()