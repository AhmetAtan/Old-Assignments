# -*- coding: utf-8 -*-
"""
Created on Tue Dec 15 12:45:20 2020

@author: Sun Bilgisayar
"""


#100 tane sıfır içeren liste oluşturma
v=[0]*100
#program çalışırken kullanıcı bir sayı girer
x=int(input("bir tam sayı giriniz:"))
v[x]=1 #x Nedir?