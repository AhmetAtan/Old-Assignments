# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 13:08:16 2020

@author: Sun Bilgisayar
"""

from math import cos, sin, pi, radians
x = int(input('Bir değer giriniz'))
for n in (1,15):
    log=(2,n)
    n=1
    L=15

x=radians(x)

fonk_x = cos((n*log(2,n)*x)/L) + sin((n*pi*x)/L)

print(fonk_x)