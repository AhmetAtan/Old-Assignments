# -*- coding: utf-8 -*-
"""
Created on Sun Nov  8 13:56:20 2020

@author: Sun Bilgisayar
"""

for i in range(10):
    print("{0:3} {1:5}".format(i, 10**i))