# -*- coding: utf-8 -*-
"""
Created on Tue Dec 15 12:30:28 2020

@author: Sun Bilgisayar
"""

def make_list():
result=[]
in_val=0
while in_val>=0:
        in_val=int(input("enter integer(-1 quits):"))
        if in_val>=0:
            result+=[in_val]
return result
def main():
    col=make_list()
    print(col)
main()