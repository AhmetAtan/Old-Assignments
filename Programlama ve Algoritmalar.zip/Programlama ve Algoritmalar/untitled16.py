# -*- coding: utf-8 -*-
"""
Created on Fri Nov 27 10:58:10 2020

@author: Sun Bilgisayar
"""

Y = 15 if True: x = 25 print (y)