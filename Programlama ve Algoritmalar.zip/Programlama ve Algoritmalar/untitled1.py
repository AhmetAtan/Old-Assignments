# -*- coding: utf-8 -*-
"""
Created on Tue Nov  3 12:47:47 2020

@author: Sun Bilgisayar
"""
sum=0
for i in range (1,100):
    sum+=i
print(sum)