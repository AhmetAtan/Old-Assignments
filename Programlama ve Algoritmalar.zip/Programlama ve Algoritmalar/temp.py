deger1 = int(input("bir tam sayi girin"))
deger2 = int(input("bir tam sayi daha girin"))
toplam = deger1 + deger2
print("toplam sonucu = ", toplam)
print(deger1, "ile", deger2, "nin toplamı", toplam, "dir.")







