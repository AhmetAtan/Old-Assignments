# -*- coding: utf-8 -*-
"""
Created on Mon Dec 21 17:53:27 2020

@author: Sun Bilgisayar
"""
a=[4,5,6,7,9]
b=[5,12,1,0,1]
toplam=0
sonuç=0
for i in a:
    toplam=toplam+i
ortalama1=toplam/5
for k in b:
    sonuç=sonuç+k
ortalama2=sonuç/5
yeniliste=[ortalama1,ortalama2]
print(yeniliste)