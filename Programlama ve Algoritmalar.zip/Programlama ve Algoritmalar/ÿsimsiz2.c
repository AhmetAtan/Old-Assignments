#include <stdio.h>
// 3.asama: Geometrik sekillerin alanini alalim.Sekiller:Ucgen,Daire,Yamuk,Dikdortgen
int taban, yukseklik, yaricap, paralelbir, paraleliki, kisakenar , uzunkenar;   //degiskenler
//Ucgenin alani:(taban*yukseklik)/2 Daire alani:pi*yaricapinkaresi Yamuk:paralelkenarlar toplami /2*yukseklik Dikdortgen:kisakenar*uzunkenar
void menu()
{
	printf("\n<------------>\n\n");
	printf("Geometrik sekillerin alani alma islevi goren algoritma\n\n");
	printf("<------------>\n\n");
	printf("Geometrik Sekillerin Menusu\n");
	printf("Ucgenin Alani icin [1]\n");
	printf("Dairenin Alani icin [2] \n");
	printf("Dikdortgenin Alani icin [3] \n");
	printf("Yamugun Alani icin   [4]\n");
	printf("Cikis icin  [-1]\n");
	printf("\nAlanini almak istediginiz geometrik sekil:");
}
//Veri girisleri
void sayiAl()
{
	printf("Ucgenin Alani icin tabani giriniz:");
	scanf("%d",&taban);
	printf("Ucgenin Alani icin yukseklik giriniz:");
	scanf("%d",&yukseklik);
}
void sayiAldaire()
{
	printf("Daire Alani icin yaricapi giriniz:");
	scanf("%d",&yaricap);
}
void sayiAldikdortgen()
{
	printf("Dikdorgenin Alani icin kisakenari giriniz:");
	scanf("%d",&kisakenar);
	printf("Dikdorgenin Alani icin uzunkenari giriniz:");
	scanf("%d",&uzunkenar);
}
void sayiAlyamuk()
{
	printf("Yamugun Alani icin paralelkenarlardan birincisini giriniz:");
	scanf("%d",&paralelbir);
	printf("Yamugun Alani icin paralelkenarlardan ikincisini giriniz:");
	scanf("%d",&paraleliki);
	printf("Yamugun Alani icin yuksekligi giriniz:");
	scanf("%d",&yukseklik);
}
//Alanlarin islemi
int islemYap(int islemler)
{
	int alan;
	switch(islemler)
	{
		case 1: alan=(taban*yukseklik)/2;
		break;
		case 2: alan=3*(yaricap*yaricap);
		break;
		case 3: alan=kisakenar*uzunkenar;
		break;
		case 4: alan=(paralelbir+paraleliki/2)*yukseklik;
	}
return alan;
}
//sonu�lar�n islemleri
void sonucGoster(int giris, int cikti)
{
	switch(giris)
	{
		case 1: printf("%d*%d/2=%d\n",taban,yukseklik,cikti);
		break;
		case 2: printf("3*(%d*%d)=%d\n",yaricap,yaricap,cikti);
		break;
		case 3: printf("%d*%d=%d\n",kisakenar,uzunkenar,cikti);
		break;
		case 4: printf("(%d+%d/2)*%d=%d\n",paralelbir,paraleliki,yukseklik,cikti);
	}
}

int main()
{
	int alan, secim;
	menu();  
	scanf("%d",&secim);
	while(secim!=-1)
	{
		if (secim==1)
		{
			sayiAl();
		alan=islemYap(secim);
		sonucGoster(secim,alan);
		}
		if (secim==2)
		{
			sayiAldaire();
		alan=islemYap(secim);
		sonucGoster(secim,alan);
		}
		if (secim==3)
		{
			sayiAldikdortgen();
		alan=islemYap(secim);
		sonucGoster(secim,alan);
		}
		if (secim==4)
		{
			sayiAlyamuk();
		alan=islemYap(secim);
		sonucGoster(secim,alan);
		}
		
		menu();
		scanf("%d",&secim);
	}
		
	return 0;
}

