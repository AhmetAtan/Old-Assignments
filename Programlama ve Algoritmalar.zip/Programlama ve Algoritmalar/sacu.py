# -*- coding: utf-8 -*-
"""
Created on Mon Oct 26 19:05:34 2020

@author: Enes Canakçay
"""

miktar = int(input("Miktarı giriniz:"))
yuztl = miktar // 100
miktar = miktar % 100
ellitl = miktar // 50
miktar = miktar % 50
yirmitl = miktar // 20
miktar = miktar % 20
ontl = miktar // 10
miktar = miktar % 10
bestl = miktar // 5
miktar = miktar % 5
print ("100 tl=",yuztl,"50 tl=",ellitl,"20 tl=",yirmitl,"10 tl=",ontl,"5 tl=",bestl)

