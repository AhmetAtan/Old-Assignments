# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 12:42:30 2020

@author: Sun Bilgisayar
"""

from math import cos, sin, pi, radians 


x = int(input("bir x değeri giriniz:"))
n = 12
L = 15
x= radians(x)

f_x = cos((n*pi*x)/L) + sin((n*pi*x)/L)

print(f_x)