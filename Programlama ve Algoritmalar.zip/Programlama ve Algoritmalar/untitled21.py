# -*- coding: utf-8 -*-
"""
Created on Tue Dec 15 12:59:19 2020

@author: Sun Bilgisayar
"""

def main():
    a=[2,4,6,8]
    print(a)
    print(sum(a))
    make_zero(a)
    print(a)
    print(sum(a))
    a=[]
    print(a)
    print(sum(a))
    a=random_list(10)
    print(a)
    

def sum (lst):
    result=0
    for item in lst:
        result+=item
    return result
def make_zero(lst):
    for i in range(len(lst)):
        lst[i]_0
def random_list(n):
    import random
    result=[]
    for i in range