# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 13:49:14 2020

@author: Sun Bilgisayar
"""

from time import sleep
for sayi in range(10, -1, -1):
    print(sayi)
    sleep(1)