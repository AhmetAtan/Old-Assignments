# -*- coding: utf-8 -*-
"""
Created on Mon Dec 21 18:03:53 2020

@author: Sun Bilgisayar
"""

from math import sqrt
 
liste= [0,0,0,0,0];
for x in range(5):
    liste[x]=int(input("Sayı Giriniz: "));

 
def standartsapma(a):
    aratop2=0
    aratop=0
    ort=0
    sonuc=0
    for num in range(1,len(a)+1):           
        ort=a[num-1]+ort                       
    ort=ort/len(a)                          
 
    
    for num in range(1,len(a)+1):           
        aratop2=a[num-1]                    
        aratop=aratop+((aratop2-ort)**2)    
    aratop=aratop/(len(a)-1)                
 
    sonuc=sqrt(aratop)
 
    print(sonuc)
    return(sonuc)
    
standartsapma(liste)
