# -*- coding: utf-8 -*-
"""
Created on Tue Dec 15 12:47:22 2020

@author: Sun Bilgisayar
"""
#100 tane sıfır içeren liste oluşturuldu
v=[0*100]
#Program çalışırken kullanıcı bir sayı girer
x=int(input("bir tam sayı giriniz:"))
#Dizin listenin sınırları içinde olduğundan emin olun
if 0<=x<len(v):
    v[x]=1 #
else:
    print("Geçersiz değer girdiniz")