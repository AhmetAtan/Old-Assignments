# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 14:05:07 2020

@author: Sun Bilgisayar
"""

import turtle
turtle.pencolor("red1")
turtle.forward(300)
turtle.left(120)

turtle.pencolor("blue")
turtle.forward(300)
turtle.left(120)

turtle.pencolor("green")
turtle.forward(300)
turtle.left(120)

turtle.hideturtle()
turtle.exitonclick()