# -*- coding: utf-8 -*-
"""
Created on Tue Dec 22 13:04:58 2020

@author: Sun Bilgisayar
"""

fruits=["apple","banana","cherry"]
fruits.append("orange")
print(fruits)

fruits=["apple","banana","cherry","orange"]
x=fruits.count("cherry")
print(x)

fruits=["apple","banana","cherry","orange"]
x=fruits.copy()
print(x)

fruits=["apple","banana","cherry","orange"]
fruits.clear()
print(fruits)

fruits=["apple","banana","cherry","orange"]
x=fruits.index("cherry")
print(x)

