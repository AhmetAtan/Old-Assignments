# -*- coding: utf-8 -*-
"""
Created on Sat Oct 31 14:09:16 2020

@author: Ahmet Atan
"""
Not=int(input("Lütfen puanınızı giriniz:"))
if (Not>100):
    print("Girdiğiniz yanlıştır")
elif(100<=Not>=95):
    print("Harf notunuz A.")
elif(Not>=90):
    print("Harf notunuz A-.")
elif(Not>=85):
    print("Harf notunuz B+.")
elif(Not>=80):
    print("Harf notunuz B.")
elif(Not>=75):
    print("Harf notunuz B-.")
elif(Not>=70):
    print("Harf notunuz C+.")
elif(Not>=65):
    print("Harf notunuz C.")
elif(Not>=60):
    print("Harf notunuz C-.")
elif(Not>=0):
    print("Harf notunuz F.")
