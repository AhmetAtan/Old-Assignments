# -*- coding: utf-8 -*-
"""
Created on Tue Dec 15 12:40:12 2020

@author: Sun Bilgisayar
"""

def main():
    a=list(range(0,10))
    print(a)
    a=list(range(10, -1, -1))
    print(a)
    a=list(range(0, 100, 10))
    print(a)
    a=list(range(-5, 6))
    print(a)
main()