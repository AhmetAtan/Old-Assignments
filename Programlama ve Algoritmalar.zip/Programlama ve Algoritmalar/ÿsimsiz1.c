#include <stdio.h>
// 2.asama:  -1 yazilana kadar kullanicidan sayi alan ve en kucuk sayi ile en buyuk sayilari gosteren algoritma.
int main ()
{
	printf("^^^^^^^^^^^^^^^^^^^\n");
	printf("Program -1 yazilana kadar kullanicidan sayi alir ve en kucuk sayi ile en buyuk sayiyi sonuc olarak gosterir.\n");
	printf("^^^^^^^^^^^^^^^^^^^\n");
	
	int enbuyuk= 0;
	int enkucuk= 9999999;
	int sayi= 0;

	while (sayi!=-1)
	{
		printf("Algoritmaya sayilarinizi giriniz:");
		
		scanf("%d",&sayi);
		if (sayi==-1)
    {
    	continue;
	}
		if (sayi>enbuyuk)
    
    	enbuyuk=sayi;
    
    if (sayi<enkucuk)
    enkucuk=sayi;		
		
}
	printf("Girilen en buyuk sayi:%d\n",enbuyuk);	
		printf("Girilen en kucuk sayi:%d",enkucuk);
	return 0;	
	}

