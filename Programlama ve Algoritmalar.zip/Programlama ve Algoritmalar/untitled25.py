# -*- coding: utf-8 -*-
"""
Created on Tue Dec 22 12:50:06 2020

@author: Sun Bilgisayar
"""

matris=[[1]*5]*5
for satir in matris:
    for eleman in satir:
        print("{:>4}".format(eleman), end = "")
    print("\n")

for i in range(5):
    for j in range(5):
        matris[i][j]=2
    print("\n")
for satir in matris:
    for eleman in satir:
        print("{:>4}".format(eleman), end="")
    print("\n")