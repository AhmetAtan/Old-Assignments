# -*- coding: utf-8 -*-
"""
Created on Tue Dec  1 12:31:56 2020

@author: Sun Bilgisayar
"""

def my_func(x):
    global k
    k = 11
    return c * x

def main():
    global c
    c = 5
    s = my_func(9)
    print(s*k)
    
main()