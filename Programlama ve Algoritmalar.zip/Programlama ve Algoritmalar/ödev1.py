# -*- coding: utf-8 -*-
"""
Created on Mon Oct 26 13:49:29 2020

@author: Sun Bilgisayar
"""

girilenpara = int(input("Lütfen para miktarını giriniz="))
a = girilenpara // 100
girilenpara = girilenpara % 100
b = girilenpara // 50
girilenpara = girilenpara % 50
c = girilenpara // 20
girilenpara = girilenpara % 20
d = girilenpara // 10
girilenpara = girilenpara % 10
e = girilenpara // 5
girilenpara = girilenpara % 5
print ("100Tl'lik bankot=",a,"adet","50Tl'lik bankot=",b,"adet","20Tl'lik banknot=",c,"adet","10Tl'lik banknot=",d,"adet","5Tl'lik banknot=",e,"adet")

