# -*- coding: utf-8 -*-
"""
Created on Tue Dec 15 13:12:40 2020

@author: Sun Bilgisayar
"""


listem=[3,45,5,6,7]
with open("denem_dosyasi.csv","w") as f:
    for sayi in listem:
        f.write("%s\n"%sayi)