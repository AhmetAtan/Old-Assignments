# -*- coding: utf-8 -*-
"""
Created on Tue Dec  1 12:28:44 2020

@author: Sun Bilgisayar
"""

def ebob(a, b):
    if b==0: return a
    return ebob(b, a%b)
print(ebob(20, 12))