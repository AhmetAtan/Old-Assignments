# -*- coding: utf-8 -*-
"""
Created on Tue Dec 22 12:17:35 2020

@author: Sun Bilgisayar
"""

matris=[[2,3,4,5],[5,3,4,3],[6,4,0,-3]]
for satir in matris:
    for eleman in satir:
        print("{:>4}".format(eleman), end = "")
    print("\n")
    
print("......\n")
matris2=[[0]*4]*3
matris2[1][2]=5
for satir in matris2:
    for eleman in satir:
        print("{:>4}".format(eleman), end = "")
    print("\n")