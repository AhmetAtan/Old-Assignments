# -*- coding: utf-8 -*-
"""
Created on Tue Dec 15 12:50:31 2020

@author: Sun Bilgisayar
"""

a=list(range(10,51,10))
del a[2]
print(a)

b=list(range(32))
del b[0:31]
print(b)