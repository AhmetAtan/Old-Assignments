# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 13:05:44 2020

@author: Sun Bilgisayar
"""

value=int(input("0-10 arası bir sayı giriniz:"))
if value>=0:
    if value<=10:
        print(value,"evet 0-10 arası.")
    else:
        print(value,"10dan büyük.")
else:
    print(value,"0 dan küçük.")
print("Bitti.")
