# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 13:12:01 2020

@author: Sun Bilgisayar
"""

cevap = int(input("Elektrik var mı?"))
if cevap==1:
    print("yardımı başka yerde arayın")
else:
    cevap=int(input("fişe takılı ise 1 e basın"))
    if(cevap!=1):
        print("fişe takın")
    else:
        cevap=int(input("düğme açık ise 1 e basın"))
        if(cevap!=1):
            print("düğmeyi açın")
        else:
            cevap=int(input("sigorta ok ise 1 e basın"))
            if(cevap!=1):
                print("sigortayı düzelt")
            else:
                print("yardımı başka yerde arayın")