# -*- coding: utf-8 -*-
"""
Created on Tue Nov 10 13:44:01 2020

@author: Sun Bilgisayar
"""

from time import perf_counter
sum = 0
start =perf_counter()
for n in range(1,100000001):
    sum += n
elapsed=perf_counter() - start
print("sum:",sum,"time",elapsed)