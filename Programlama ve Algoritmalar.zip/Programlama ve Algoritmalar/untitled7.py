# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 13:42:48 2020

@author: Sun Bilgisayar
"""

value=(input("Haftanın kaçıncı günü"))
if value=="Monday" or value=="mondey":
    print("pazartesi")
elif value=="Tuesday" or value=="tuesday":
    print("salı")
elif value=="Wednesday" or value=="wednesday":
    print("çarşamba")
elif value=="Thursday" or value=="thursday":
    print("perşembe")
elif value=="Friday" or value=="friday":
    print("cuma")
elif value=="Saturday" or value=="saturday":
    print("cumartesi")
elif value=="Sunday" or value=="sunday":
    print("pazar")
else:
    print("yazım hastası")
